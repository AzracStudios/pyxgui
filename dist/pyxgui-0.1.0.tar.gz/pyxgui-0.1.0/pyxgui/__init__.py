from os import path

file_path: str = path.abspath(__file__)
last_slash: int = file_path.rfind("/")
file_path = path.join(file_path[:last_slash], "art.txt")



with open(file_path, "r", encoding="UTF-8") as f:
  print("".join(f.readlines()))
